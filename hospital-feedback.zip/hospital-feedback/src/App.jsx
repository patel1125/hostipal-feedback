import FeedbackForm from './features/feedback/FeedbackForm'
import FeedbackTable from './features/feedback/FeedbackTable'

export default function App() {
  return (
    <div className="container mt-4">
      <h2 className="text-center text-primary mb-4">
        Hospital & Doctor Feedback System
      </h2>
      <FeedbackForm />
      <FeedbackTable />
    </div>
  )
}
